samples

Berklee Boulanger FX samples
http://archive.org/details/Berklee44BoulangerFX

License:  Creative Commons Attribution 3.0
